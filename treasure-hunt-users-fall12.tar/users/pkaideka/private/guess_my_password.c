// Almost impossible game in which the user must guess pkaideka's 
// password. But because the password is stored as a string in the
// executable, it can be found by the stirngs program. 

#include <string.h>
#include <stdio.h>

int main (int argc, char** argv) {
  if (argc != 2) {
    printf("Usage -- guess_my_password <your-guess>\n");
  } else if ((strcmp(argv[1],"Wybittydu,tys")) == 0) {
    /* Wybittydu,tys = "When you believe in things that you dont understand, then you suffer", from Stevie Wonder's song Superstition  */
    printf("You guessed my password!\n"); 
  } else {
    printf("That's not my password!\n"); 
  }
}

